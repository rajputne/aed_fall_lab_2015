package business;

import java.util.ArrayList;


public class AccountDirectory {

    private ArrayList<Account> accountList;

    public AccountDirectory() {
        this.accountList = new ArrayList<>();
    }
    
    public ArrayList<Account> getAccountList() {
        return accountList;
    }

    public void setAccountList(ArrayList<Account> accountList) {
        this.accountList = accountList;
    }
    
    public Account addAccount() {
        Account a = new Account();
        accountList.add(a);
        return a;
    }
    
    public void deleteAccount(Account a) {
        accountList.remove(a);
    }
    
    public Account searchAccount(String accountNum) {
        for (Account a : accountList) {
            if (a.getAccountNum().equals(accountNum)) {
                return a;
            }
        }
        return null;
    }
    
}
